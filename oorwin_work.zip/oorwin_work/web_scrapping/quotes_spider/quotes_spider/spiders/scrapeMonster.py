from typing import Iterable
from scrapy.http import Request
from selenium import webdriver
from scrapy import Spider
from scrapy.selector import Selector
from selenium.webdriver.common.by import By
from selenium.common.exceptions import NoSuchElementException
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC


class scrapeMonster(Spider):
    name="scrapeMonster"
    allowed_domains = ['foundit.in']

    def start_requests(self):
        self.driver = webdriver.Chrome()
        self.driver.get('https://foundit.in/')
        sel = Selector(text=self.driver.page_source)
        self.driver.find_element(By.XPATH, '//div[text()="Banking"]').click()
        pagination_links = self.driver.find_elements(By.XPATH, '//a[contains(@class, "number")]')
        # pagination_links = WebDriverWait(self.driver, 10).until(EC.presence_of_all_elements_located((By.XPATH, '//a[contains(@class, "number")]')))
        for link in pagination_links:
            print("linkk is :")
            print(link)
            link.click()
            job_titles = self.driver.find_elements(By.CLASS_NAME, 'jobTitle')
            companies = self.driver.find_elements(By.CLASS_NAME, 'companyName')
            locations = self.driver.find_elements(By.CLASS_NAME, 'under-link')
            sal_details = self.driver.find_elements(By.CLASS_NAME, 'details')

            arr=[]
            for job, company, location, sal in zip(job_titles, companies, locations, sal_details):
                job_details = {
                    'job_role': job.text,
                    'companies': company.text,
                    'location': location.text,
                    'salary': sal.text
                }
                arr.append(job_details)

            print(arr)


            with open('job_details.txt', 'a') as f:  
                for item in arr:
                    f.write("%s\n" % item)

        # self.driver.quit()


# class scrapeMonster(Spider):
#     name="scrapeMonster"
#     allowed_domains = ['foundit.in']

#     def start_requests(self):
#         self.driver = webdriver.Chrome()
#         self.driver.get('https://foundit.in/')
#         sel = Selector(text=self.driver.page_source)
#         self.driver.find_element(By.XPATH, '//div[text()="Banking"]').click()
#         job_titles = self.driver.find_elements(By.CLASS_NAME, 'jobTitle')
#         companies = self.driver.find_elements(By.CLASS_NAME, 'companyName')
#         locations = self.driver.find_elements(By.CLASS_NAME,'under-link')
#         sal_details = self.driver.find_elements(By.CLASS_NAME,'details')

#         arr=[]
#         for job, company, location,sal in zip(job_titles, companies, locations, sal_details):
#             job_details = {
#                 'job_role':job.text,
#                 'companies':company.text,
#                 'location': location.text,
#                 'salary': sal.text
#             }
#             arr.append(job_details)
#         print(arr)
#         with open('job_details.txt', 'w') as f:
#             for item in arr:
#                 f.write("%s\n" % item)

            








    # def parse_book(self,response):
    #     yield{'url':response.url}


    # WebDriverWait(self.driver, 10).until(EC.element_to_be_clickable((By.XPATH, '//div[text()="Work From Home"]'))).click()
        # job_titles = WebDriverWait(self.driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'jobTitle')))
        # companies = WebDriverWait(self.driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'companyName')))
        # locations = WebDriverWait(self.driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'under-link')))
        # sal_details = WebDriverWait(self.driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'details')))