from selenium import webdriver
from selenium.webdriver.common.by import By
from scrapy import Spider
from scrapy.selector import Selector
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

class diceSpider(Spider):
    name = "diceScrape"
    allowed_domains = ['dice.com']

    def start_requests(self):
        self.driver = webdriver.Chrome()
        self.driver.get('https://www.dice.com/jobs?countryCode=US&radius=30&radiusUnit=mi&page=1&pageSize=20&language=en&eid=0904')
        sel = Selector(text=self.driver.page_source)
        title = WebDriverWait(self.driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'card-title-link')))
        print(title)


