from flask import Flask, render_template
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

app = Flask(__name__)

@app.route('/')
def form():
    driver = webdriver.Chrome()
    driver.get('https://www.foundit.in/search/IT-&-Telecom-jobs?searchId=d8a1eddd-5319-46ff-a319-0737c051f973&spl=IN-Acq-SEM-Google-IP_IN_SER_Monster_Brand_AllMatch-GSN-Monster_Resume-monster-Both-Brand---637202034922---CPC-6645446156&utm_campaign=IN_Acq_SEM-Google-IP_IN_SER_Monster_Brand_AllMatch-GSN-Monster_Resume-monster-&utm_medium=SEM&utm_source=Google-GSN-CPC&utm_term=SEM_monster&gad_source=1&gclid=CjwKCAjwwr6wBhBcEiwAfMEQs92dGDc39RWWKJ55BbiXoiprrf61HxzEldo8LTwsM5Jhx5fxao2DfRoCLrIQAvD_BwE')
    content = driver.page_source
    job_titles = driver.find_elements(By.CLASS_NAME,'jobTitle')
    print(job_titles)
    return render_template('form.html')

if __name__ == '__main__':
    app.run(debug=True)
