from selenium import webdriver
from selenium.webdriver.common.by import By
from scrapy import Spider
from scrapy.selector import Selector

class jobsSpider(Spider):
    name = "jobsScrape"
    allowed_domains = ['naukri.com']

    def start_requests(self):
        try:
            self.driver = webdriver.Chrome()
            self.driver.get('https://www.naukri.com/remote-jobs?src=discovery_trendingWdgt_homepage_srch')
            sel = Selector(text=self.driver.page_source)
            tag= sel.xpath('//h3')
            print(tag)
            # with open('1.txt','w') as e:
            #     e.write(self.driver.page_source)
            # pg = self.driver.page_source
            # elements = self.driver.find_elements(By.CLASS_NAME,'cust-job-tuple')
            # print(elements)
            # for element in elements:
            #     # try:
            #     print('ele',element)
            #     print("element is")
        except Exception as e:
            print("EXCEPTION",str(e))
            # print(element)
            # job_title = element.find_element(By.XPATH('.//a[@class="title"]')).text
            # job_exp = element.find_element(By.XPATH('.//span[@class="expwdth"]')).text

            # print("Job Title:", job_title)
            # print("Experience:", job_exp)