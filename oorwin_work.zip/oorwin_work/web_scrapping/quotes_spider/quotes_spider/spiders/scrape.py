from selenium import webdriver
from selenium.webdriver.common.by import By


def scrape_website():
    driver = webdriver.Chrome()
    driver.get('https://www.foundit.in/search/IT-&-Telecom-jobs?searchId=d8a1eddd-5319-46ff-a319-0737c051f973&spl=IN-Acq-SEM-Google-IP_IN_SER_Monster_Brand_AllMatch-GSN-Monster_Resume-monster-Both-Brand---637202034922---CPC-6645446156&utm_campaign=IN_Acq_SEM-Google-IP_IN_SER_Monster_Brand_AllMatch-GSN-Monster_Resume-monster-&utm_medium=SEM&utm_source=Google-GSN-CPC&utm_term=SEM_monster&gad_source=1&gclid=CjwKCAjwwr6wBhBcEiwAfMEQs92dGDc39RWWKJ55BbiXoiprrf61HxzEldo8LTwsM5Jhx5fxao2DfRoCLrIQAvD_BwE')
    
    job_titles = driver.find_elements(By.CLASS_NAME, 'jobTitle')
    companies = driver.find_elements(By.CLASS_NAME, 'companyName')
    locations = driver.find_elements(By.CLASS_NAME,'under-link')
    sal_details = driver.find_elements(By.CLASS_NAME,'details')
    arr=[]
    for job, company, location,sal in zip(job_titles, companies, locations, sal_details):
        job_details = {
            'job_role':job.text,
            'companies':company.text,
            'location': location.text,
            'salary': sal.text
        }
        arr.append(job_details)
    print(arr)
    
    driver.quit()

if __name__ == '__main__':
    scrape_website()
