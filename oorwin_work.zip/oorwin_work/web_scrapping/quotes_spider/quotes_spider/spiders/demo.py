import scrapy
from selenium import webdriver
from scrapy import Spider
from scrapy.selector import Selector
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

driver = webdriver.Chrome()

# def main():
#     driver.get('https://www.dice.com/jobs?countryCode=US&radius=30&radiusUnit=mi&page=1&pageSize=20&language=en&eid=0904')
#     title = driver.find_element(By.CLASS_NAME,'card-title-link')
#     print(title)

# if __name__ == '__main__':
#     main()
driver.get('https://www.dice.com/jobs?countryCode=US&radius=30&radiusUnit=mi&page=1&pageSize=20&language=en&eid=0904')
# title = driver.find_element(By.CLASS_NAME,'card-title-link')
title = WebDriverWait(driver, 10).until(EC.presence_of_element_located((By.CLASS_NAME, 'card-title-link')))

print(title.text)
