from flask import Flask, render_template
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

app = Flask(__name__)

@app.route('/')
def index():
    driver = webdriver.Chrome()
    driver.get('https://www.dice.com/jobs?countryCode=US&radius=30&radiusUnit=mi&page=1&pageSize=20&language=en&eid=0904')
    try:
            job_titles = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'card-title-link')))
            companies = WebDriverWait(driver, 10).until(EC.presence_of_all_elements_located((By.CLASS_NAME, 'card-company')))
            print(job_titles)
            arr = []
            for job, company in zip(job_titles, companies):
                job_title = job.text
                company = company.text.split('\n')[0]
            arr.append({
                'job_title' : job_title,
                'company':company
            })
            print(arr)
        
    finally:
        driver.quit()
    return render_template('index.html', data=arr)

if __name__ == '__main__':
    app.run(debug=True)
