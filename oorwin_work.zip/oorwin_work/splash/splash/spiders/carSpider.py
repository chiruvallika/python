# import scrapy
# from scrapy_splash import SplashRequest

# class CarSpider(scrapy.Spider):
#     name = 'car_spider'
#     start_urls = ['https://www.example.com']  # Replace with your actual URL

#     def start_requests(self):
#         for url in self.start_urls:
#             yield SplashRequest(url, self.parse, args={'wait': 2})

#     def parse(self, response):
#         # Extract data using XPath selectors
#         car_make_model = response.xpath('//h2[@class="vehicle-card-title"]/a/text()').get()
#         car_price = response.xpath('//span[@class="portal-price"]/text()').get()
#         car_engine = response.xpath('//li[@class="engine"]/text()').get()
#         car_stock_number = response.xpath('//li[@class="stockNumber"]/text()').get()
#         car_exterior_color = response.xpath('//li[contains(@class, "exteriorColor")]/text()').get()
#         car_fuel_economy = response.xpath('//li[@class="fuelEconomy"]/text()').get()

#         # Yield or process extracted data
#         yield {
#             'car_make_model': car_make_model,
#             'car_price': car_price,
#             'car_engine': car_engine,
#             'car_stock_number': car_stock_number,
#             'car_exterior_color': car_exterior_color,
#             'car_fuel_economy': car_fuel_economy
#         }


import scrapy
from scrapy_splash import SplashRequest

lua_script = """
function main(splash, args)
   splash:go(args.url)

   while not splash:select(".post") do
     splash:wait(1)  -- Increase the wait time to 1 second
     print("Waiting for .post elements...")
   end

   return splash:html()
end
"""

class ScrapingClubSpider(scrapy.Spider):
    name = "scraping_club"
    allowed_domains = ["scrapingclub.com"]

    def start_requests(self):
        url = "https://scrapingclub.com/exercise/list_infinite_scroll/"
        yield SplashRequest(url, callback=self.parse, endpoint="execute", args={"lua_source": lua_script})


    def parse(self, response):
        # iterate over the product elements
        for product in response.css(".post"):
            url = product.css("a").attrib["href"]
            image = product.css(".card-img-top").attrib["src"]
            name = product.css("h4 a::text").get()
            price = product.css("h5::text").get()
        
            # add scraped product data to the list
            # of scraped items
        
            yield {
                "url": url,
                "image": image,
                "name": name,
                "price": price
            }
