import scrapy
from scrapy.http import Request

class CarScrape(scrapy.Spider):
    name = 'books'
    allowed_domains = ['books.toscrape.com']
    start_urls = ['https://books.toscrape.com/']
    def parse(self,response):
        books = response.xpath('//h3/a/@href').extract()
        for book in books:
            abs_url = response.urljoin(book)
            yield Request(abs_url,callback = self.parse_book)
    def parse_book(self,response):
        pass
    