from flask import Flask, render_template, request
from selenium import webdriver
from urllib.parse import urlencode
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.common.exceptions import NoSuchElementException

app = Flask(__name__)

def scrape_foundit(role, location, experience):
    driver = webdriver.Chrome()
    base_url = "https://www.foundit.in/srp/results?"
    query_params = {
        "start": 0,
        "sort": 1,  
        "limit": 15,
        "query": role,
        "locations": location,
        "experience": experience,
        "experienceRanges": f"{experience}~{experience}",
        
    }
    encoded_params = urlencode(query_params)
    
    job_details_list = []
    
    try:
        start = 0
        while True:
            query_params['start'] = start
            full_url = base_url + encoded_params
            print("url is")
            print(full_url)
            driver.get(full_url)
            # WebDriverWait(driver, 10).until(EC.visibility_of_element_located((By.CLASS_NAME, 'job-list')))
            
            job_titles = driver.find_elements(By.CLASS_NAME, 'jobTitle')
            companies = driver.find_elements(By.CLASS_NAME, 'companyName')
            locations = driver.find_elements(By.CLASS_NAME, 'details')
            experiences = driver.find_elements(By.XPATH,'//div[@class="details" and contains(text(), "Years")]')
            # experiences = driver.find_elements(By.CLASS_NAME, 'details')
            skills = driver.find_elements(By.CLASS_NAME,'skillTitle')
            job_types = driver.find_elements(By.XPATH,'//div[@class="details" and contains(text(), "time")]')
            
            for job, company, location, exp, job_type, skill in zip(job_titles, companies, locations, experiences, job_types, skills):
                # skills = [skill.text for skill in skill_list.find_elements(By.CLASS_NAME, 'skillTitle')]
                job_details = {
                    'job_role': job.text,
                    'companies': company.text,
                    'location': location.text,
                    'experience': exp.text,
                    'job_type': job_type.text,
                    'skills':skill.text
                }
                job_details_list.append(job_details)
            # query_params['start'] += 15
            active_pages = driver.find_elements(By.CLASS_NAME, 'activePage')
            if not active_pages or start >= 5:  
                break
            # if not driver.find_elements(By.CLASS_NAME, 'activePage') or start >= 50:
            #     break
            # page_count += 1
            # try:
            #     next_button = driver.find_element(By.XPATH, "//i[contains(@class, 'mqfisrp-right-arrow')]")
            #     next_button.click()
            # except NoSuchElementException:
            #     break
            start += 2
            
        
        return job_details_list

    finally:
        # driver.quit()
        print(job_details_list)

@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        role = request.form['role']
        location = request.form['location']
        experience = request.form['experience']
        scraped_data = scrape_foundit(role, location, experience)
        return render_template('scrapedData.html', jobs=scraped_data)
    return render_template('index.html')

if __name__ == '__main__':
    app.run(debug=True)
