from selenium import webdriver
from urllib.parse import urlencode

def scrape_website(role, location, experience):
    driver = webdriver.Chrome()

    base_url = "https://www.foundit.in/srp/results?"

    query_params = {
        "query": role,
        "locations": location,
        "experience": experience,
        "experienceRanges": f"{experience}~{experience}"  
    }

    encoded_params = urlencode(query_params)

    full_url = base_url + encoded_params

    driver.get(full_url)


role = input("Enter the job title or role: ")
location = input("Enter the location: ")
experience = input("Enter the experience level: ")

scrape_website(role, location, experience)

# from flask import Flask, render_template, request
# from selenium import webdriver
# from urllib.parse import urlencode
# from selenium.webdriver.common.by import By

# app = Flask(__name__)

# def scrape_foundit(role,location,experience):
#     driver = webdriver.Chrome()
#     base_url = "https://www.foundit.in/srp/results?"
#     query_params = {
#         "query": role,
#         "locations": location,
#         "experience": experience,
#         "experienceRanges": f"{experience}~{experience}"
#     }
#     encoded_params = urlencode(query_params)
#     full_url = base_url + encoded_params
#     print(full_url)
#     driver.get(full_url)
#     job_titles = driver.find_elements(By.CLASS_NAME, 'jobTitle')
#     print('job_title: ')
#     print(job_titles)
#     companies = driver.find_elements(By.CLASS_NAME, 'companyName')
#     locations = driver.find_elements(By.CLASS_NAME,'details')
#     experiences = driver.find_elements(By.CLASS_NAME,'details')
#     # sal_details = driver.find_elements(By.CLASS_NAME,'details')

#     arr=[]
#     for job, company, location,exp in zip(job_titles, companies, locations,experiences):
#         job_details = {
#             'job_role':job.text,
#             'companies':company.text,
#             'location': location.text,
#             'experience':exp.text,
#             # 'salary': sal.text
#         }
#         print("job_details")
#         print(job_details)
#         arr.append(job_details)
#     print(arr)
    
#     driver.quit()
#     return arr

# @app.route('/',methods=['get','post'])
# def index():
#     if request.method == 'POST':
#         role = request.form['role']
#         location = request.form['location']
#         experience = request.form['experience']
#         scraped_data = scrape_foundit(role,location,experience)
#         return render_template('scrapedData.html',jobs = scraped_data)
#     return render_template('index.html')

# if __name__ == '__main__':
#     app.run(debug=True)
