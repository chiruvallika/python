import os
import math
import shutil

files = os.scandir('C:/Users/oorwin/Downloads/sample_tagging_1/sample_tagging')
file_names = [file.name for file in files if file.is_file()]

n = int(input("Enter number of files per folder."))
files_per_folder = math.ceil(len(file_names)/n)

for i,file in enumerate(file_names):
    if i < files_per_folder:
        folder_name = f"Folder_{i+1}"
        folder_path = os.path.join('C:/Users/oorwin/Downloads/files/',folder_name)
        os.makedirs(folder_path)
    curr = i // n + 1
    source =  os.path.join('C:/Users/oorwin/Downloads/sample_tagging_1/sample_tagging',file)
    destination_fol = os.path.join('C:/Users/oorwin/Downloads/files',f"Folder_{curr}")
    destination = os.path.join(destination_fol,file)
    print(destination)
    shutil.copy(source,destination)



