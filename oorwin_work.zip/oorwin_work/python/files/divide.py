import os
import math
import shutil

files = os.scandir('C:/Users/oorwin/Downloads/sample_tagging_1/sample_tagging')
file_names = [file.name for file in files if file.is_file()]

print(file_names)