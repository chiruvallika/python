import os
from pypdf import PdfReader
from PIL import Image
import pytesseract
import shutil
import fitz 
from docx import Document
from PIL import Image
import io

def extract_text_from_images(images):
    pytesseract.pytesseract.tesseract_cmd = r'C:\Users\oorwin\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'
    texts = []
    for image in images:
        text = pytesseract.image_to_string(image)
        texts.append(text)
    return " ".join(texts)

def extract_pdf(file_path):
    doc = fitz.open(file_path)
    text = []
    images = []
    for page in doc:
        content = page.get_text()
        if content:
            text.append(content)
        page_images = extract_images_from_page(page, doc)
        images.extend(page_images)
    image_texts = extract_text_from_images(images)
    text.append(image_texts)
    base_name = os.path.basename(file_path)
    pdf_name, _ = os.path.splitext(base_name)
    with open(f'{pdf_name}.txt', 'w', encoding='utf-8') as file:
        file.write(" ".join(text))

def extract_images_from_page(page, doc):
    images = []
    image_list = page.get_images(full=True)
    if image_list:
        print(f"Found a total of {len(image_list)} images in page")
        for image_info in image_list:
            xref = image_info[0]
            base_image = doc.extract_image(xref)
            if base_image:
                image_bytes = base_image["image"]
                image = Image.open(io.BytesIO(image_bytes))
                images.append(image)
    return images

def extract_docx_images_and_text(doc):
    images = []
    texts = []
    for rel in doc.part.rels.values():
        if "image" in rel.reltype and not rel.is_external:
            image_stream = io.BytesIO(rel.target_part.blob)
            image = Image.open(image_stream)
            images.append(image)
            text = pytesseract.image_to_string(image, lang='eng')
            texts.append(text)
    return images, texts

def extract_docx(file_path):
    document = Document(file_path)
    document_text = '\n'.join([p.text for p in document.paragraphs])
    images, image_texts = extract_docx_images_and_text(document)
    base_name = os.path.basename(file_path)
    docx_name, _ = os.path.splitext(base_name)
    txt_file_path = f'{docx_name}.txt'
    with open(txt_file_path, 'w', encoding='utf-8') as file:
        file.write(document_text+"\n\n")
        for i, img_text in enumerate(image_texts):
            file.write(img_text)
            
def extract_image(file_path):
    image = Image.open(file_path)
    text = pytesseract.image_to_string(image)
    base_name = os.path.basename(file_path)
    image_name, _ = os.path.splitext(base_name)
    with open(f'{image_name}.txt', 'w', encoding='utf-8') as file:
        file.write(text)

def process_files(folder_path):
    dirlist = os.listdir(folder_path)
    for filename in dirlist:
        file_path = os.path.join(folder_path, filename)
        extension = file_path.split(".")[-1].lower()
        if extension == 'pdf':
            extract_pdf(file_path)
        elif extension == 'docx':
            extract_docx(file_path)
        elif extension in ('png', 'jpg', 'jpeg'):
            extract_image(file_path)
    move_files()

def move_files():
    dirlist = os.listdir(r'C:\oorwin_work\task\practise\task2')
    os.makedirs(r'C:\oorwin_work\task\practise\task2\files')
    for i in dirlist:
        print(i)
        if i.split(".")[-1] == 'txt':
            source_path = os.path.join(r'C:\oorwin_work\task\practise\task2', i)
            destination_path = os.path.join(r'C:\oorwin_work\task\practise\task2', 'files')
            shutil.move(source_path, destination_path)


folder_path = r'C:\oorwin_work\task\parser_issues'
process_files(folder_path)
