import os
from pypdf import PdfReader
from spire.doc import *
from spire.doc.common import *
from PIL import Image
import pytesseract
import shutil
import fitz 
from PIL import Image
import io
import docx2txt

def extract_text_from_images(images):
    pytesseract.pytesseract.tesseract_cmd = r'C:\Users\oorwin\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'
    texts = []
    for image in images:
        text = pytesseract.image_to_string(image)
        texts.append(text)
    return " ".join(texts)

def extract_pdf(file_path):
    doc = fitz.open(file_path)
    text = []
    images = []
    
    for page in doc:
        content = page.get_text()
        if content:
            text.append(content)
        
        page_images = extract_images_from_page(page, doc)
        images.extend(page_images)
 
    image_texts = extract_text_from_images(images)
    text.append(image_texts)
    
    base_name = os.path.basename(file_path)
    pdf_name, _ = os.path.splitext(base_name)
    with open(f'{pdf_name}.txt', 'w', encoding='utf-8') as file:
        file.write(" ".join(text))

def extract_images_from_page(page, doc):
    images = []
    image_list = page.get_images(full=True)
    if image_list:
        print(f"Found a total of {len(image_list)} images in page")
        for image_info in image_list:
            xref = image_info[0]
            base_image = doc.extract_image(xref)
            if base_image:
                image_bytes = base_image["image"]
                image = Image.open(io.BytesIO(image_bytes))
                images.append(image)
    return images

def extract_docx(file_path):
    document = Document()
    document.LoadFromFile(file_path)
    document_text = document.GetText()
    data = extract_docx_image(file_path)
    print("file path is")
    print(file_path)
    
    base_name = os.path.basename(file_path) 
    docx_name, _ = os.path.splitext(base_name)
    with open(f'{docx_name}.txt', 'w', encoding='utf-8') as file:
        file.write(document_text)
        # file.write(data)

def extract_docx_image(file_path):
    folder_path = r'C:\oorwin_work\task\parser_issues'
    text = docx2txt.process(file_path, folder_path)
    print(folder_path)
    return text

def extract_image(file_path):
    image = Image.open(file_path)
    text = pytesseract.image_to_string(image)
    base_name = os.path.basename(file_path)
    image_name, _ = os.path.splitext(base_name)
    with open(f'{image_name}.txt', 'w', encoding='utf-8') as file:
        file.write(text)

def process_files(folder_path):
    dirlist = os.listdir(folder_path)
    for filename in dirlist:
        file_path = os.path.join(folder_path, filename)
        extension = file_path.split(".")[-1].lower()
        if extension == 'pdf':
            extract_pdf(file_path)
        elif extension == 'docx':
            extract_docx(file_path)
        elif extension in ('png', 'jpg', 'jpeg'):
            extract_image(file_path)
    move_files('files')

def move_files(folder_name):
    dirlist = os.listdir(r'C:\oorwin_work\task\practise\task2')
    for i in dirlist:
        print(i)
        if i.split(".")[-1] == 'txt':
            source_path = os.path.join(r'C:\oorwin_work\task\practise\task2', i)
            destination_path = os.path.join(r'C:\oorwin_work\task\practise\task2', folder_name)
            shutil.move(source_path, destination_path)


folder_path = r'C:\oorwin_work\task\parser_issues'
process_files(folder_path)
