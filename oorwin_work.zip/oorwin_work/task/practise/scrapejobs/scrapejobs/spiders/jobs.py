import scrapy
from selenium import webdriver
from selenium.webdriver.common.by import By
from urllib.parse import urljoin

class JobsSpider(scrapy.Spider):
    name = "jobs"
    allowed_domains = ["www.careercircle.com"]
    start_urls = ["https://www.careercircle.com/jobs"]

    # def __init__(self):
    #     self.driver = webdriver.Chrome()

    def parse(self, response):
        driver = webdriver.Chrome()
        driver.get('https://www.careercircle.com/jobs')
        last_page = driver.find_elements(By.XPATH,"//div[@class='Center_root__HY_78']/div/button")
        last_page_number = int(last_page[5].text)
        base_url = 'https://www.careercircle.com/jobs'
        arr=[]
        for i in range(1,last_page_number):
            job_titles = driver.find_elements(By.XPATH,"//a[@data-testid='job_title']")
            job_title_urls = driver.find_elements(By.XPATH, "//a[@class='Job_title__FITCw']")
            next_page = driver.find_element(By.XPATH,"//button[@aria-label='next page button']")
            next_page.click
            arr.append([job_title_url.get_attribute('href') for job_title_url in job_title_urls])
            # arr.append([job_title.text for job_title in job_titles])
        urls=[]
        for i in range(len(arr)):
            for j in arr[i]:
                urls.append(j)
        
        for job_url in urls:
            # full_url = urljoin(base_url,job_url)
            yield scrapy.Request(job_url,callback=self.parse_job)
    def parse_job(self,response):
        # print(response)
        job_title = response.xpath('//h1/text()').get()
        company = response.xpath('//div[@class="Stack_root__SHTRi LeftPanel_job_inner__9RsbA"]//p/text()').get()
        date = response.xpath('//div[@class=""//div]')
        # company = ''.join(company).strip()  
        print(job_title)
        print(company)
        # print(arr)
        # ele = 0
        # for i in range(len(arr)):
        #     ele = ele + len(arr[i])
        # print(ele)
