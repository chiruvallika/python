import os
from pypdf import PdfReader
from spire.doc import *
from spire.doc.common import *
from PIL import Image
import pytesseract
import shutil
import fitz 
from PIL import Image
import io
import docx2txt

def extract_pdf(file_path):
    reader = PdfReader(file_path)
    text = []   
    for page in reader.pages:
        content = page.extract_text()
        if content:
            text.append(content)
        extract_pdf_image(file_path)
    base_name = os.path.basename(file_path)
    pdf_name, _ = os.path.splitext(base_name)
    if content:
        with open(f'{pdf_name}.txt','w',encoding='utf-8') as file:
            file.write(" ".join(text))

def extract_docx(file_path):
    document = Document()
    document.LoadFromFile(file_path)
    document_text = document.GetText()
    extract_docx_image(file_path)
    base_name = os.path.basename(file_path) 
    docx_name, _ = os.path.splitext(base_name)
    with open(f'{docx_name}.txt', 'w', encoding='utf-8') as file:
        file.write(document_text)

def extract_image(file_path):
    pytesseract.pytesseract.tesseract_cmd = r'C:\Users\oorwin\AppData\Local\Programs\Tesseract-OCR\tesseract.exe'
    print(file_path)
    text = pytesseract.image_to_string(Image.open(file_path))
    base_name = os.path.basename(file_path)
    file_name,_ = os.path.splitext(base_name)
    if text:
        with open(f'{file_name}.txt','w', encoding='utf-8') as file:
            file.write(text)
    print(text.split("\n")[0])

def find_extension(file_path):
    extension = file_path.split(".")[-1]
    if extension == 'pdf':
        extract_pdf(file_path)
    elif extension == 'docx':
        extract_docx(file_path)
    elif extension == 'png' or extension == 'jpeg':
        extract_image(file_path)

def move_files(folder_name):
    dirlist = os.listdir(r'C:\oorwin_work\task\practise\task1')
    for i in dirlist:
        print(i)
        if i.split(".")[-1] == 'txt':
            source_path = os.path.join(r'C:\oorwin_work\task\practise\task1', i)
            destination_path = os.path.join(r'C:\oorwin_work\task\practise\task1', folder_name)
            shutil.move(source_path, destination_path)

def find_files(folder_path):
    dirlist = os.listdir(folder_path)
    for i in dirlist:
        file_path = os.path.join(folder_path,i)
        find_extension(file_path)
    move_files('files')

def extract_pdf_image(file_path):
    pdf_file = fitz.open(file_path)
    for page_index in range(len(pdf_file)):
        page = pdf_file[page_index]
        image_list = page.get_images(full=True)
        if image_list:
            print(f"Found a total of {len(image_list)} images in page {page_index}")
            for image_info in image_list:
                xref = image_info[0]
                base_image = pdf_file.extract_image(xref)
                if base_image:
                    image_bytes = base_image["image"]
                    image = Image.open(io.BytesIO(image_bytes))
                    image_filename = f"{os.path.splitext(file_path)[0]}_page_{page_index}_img_{xref}.png"
                    image.save(image_filename)

def extract_docx_image(file_path):
    folder_path = r'C:\Users\oorwin\Downloads\parser_issues\parser_issues'
    text = docx2txt.process(file_path, folder_path) 

folder_path = r'C:\Users\oorwin\Downloads\parser_issues\parser_issues'
find_files(folder_path)

