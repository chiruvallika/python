import os
import re

def read_text_files(folder_path):
    files_content = {}
    for file in os.listdir(folder_path):
        file_path = os.path.join(folder_path, file)
        if os.path.isfile(file_path):
            with open(file_path, "r", encoding='utf-8') as f:
                files_content[file] = f.read()
    return files_content

content = read_text_files(r'C:\oorwin_work\task\practise\task1\files')
for file,data in content.items():
    email_regex = r'\b[a-z0-9_+%-]+(?:\.[a-z0-9_+%+-]+)*@[a-z0-9-]{2,7}+(?:\.[a-z]{2,7})+'
    phone_regx = r'\d{10}'
    # phone_regx = r'\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4}'
    email_id = re.findall(email_regex,data)
    phone_number = re.findall(phone_regx,data)
    details = {
        'file_name': file,
        'email': email_id,
        'phone_number': phone_number
    }
    print(details)

