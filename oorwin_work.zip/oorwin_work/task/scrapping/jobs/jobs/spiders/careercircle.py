from bs4 import BeautifulSoup
from selenium import webdriver
import pandas as pd
from scrapy import Spider
from urllib.parse import urljoin
import scrapy
import json

class CareercircleSpider(Spider):
    name = "careercircle"
    allowed_domains = ["www.careercircle.com"]

    def start_requests(self):
        self.driver = webdriver.Chrome()
        self.data = []
        self.driver.get('https://www.careercircle.com/jobs')
        base_url = 'https://www.careercircle.com/jobs'
        soup = BeautifulSoup(self.driver.page_source, 'html.parser')
        job_links = soup.find_all('a', attrs={'data-testid': 'job_title'})
        
        jobs_url = [link['href'] for link in job_links if link.get('href')]
        
        for job_url in jobs_url:
            full_url = urljoin(base_url,job_url)
            yield scrapy.Request(full_url, callback=self.parse_job_details)

    def parse_job_details(self, response):
        title = response.xpath('//h1/text()').get()
        company = response.xpath('//div[@class="Stack_root__SHTRi LeftPanel_job_inner__9RsbA"]/p/text()').get()
        date = response.xpath('//div[@class="Stack_root__SHTRi LeftPanel_job_inner__9RsbA"]/div/p/text()').get()

        if title and company and date:
            self.data.append({
                'Title': title,
                'company': company,
                'date': date
                })
        else:
            self.data.append({'Title': 'Data Not Found'})
        
        print(self.data)
        with open("file1.txt", 'w') as file1:
            json.dump(self.data, file1)

    # def closed(self):
    #     print(self.data)
        # with open("file.txt", 'w') as file1:
        #     json.dump(self.data, file1)
        # df = pd.DataFrame(self.data)
        # df.to_excel('output.xlsx', index=False)
        # self.driver.quit()
