

from pypdf import PdfReader

def read_pdf():
        reader = PdfReader('81442_RanjanaSatish.pdf')
        text = []
        for page in range(len(reader.pages)):
            content = reader.pages[page]
            text.append(content.extract_text())
        print("\n".join(text))
        with open('resume_text.txt','w', encoding='utf-8') as file:
              file.write("\n".join(text))
read_pdf()