import re

with open('resume_text.txt','r', encoding='utf-8') as f:
    text = f.read()

email_regex = r'\b[a-z0-9_+%-]+(?:\.[a-z0-9_+%+-]+)*@[a-z0-9-]{2,7}+(?:\.[a-z]{2,7})+'
# email_regex = r'\b[a-z0-9_+%+-]+(?:\.[a-z0-9_+%+-]+)*@[a-z0-9-]+\.[a-z]{2,}\b'
phone_regx = r'\d{3}[-\.\s]??\d{3}[-\.\s]??\d{4}|\(\d{3}\)\s*\d{3}[-\.\s]??\d{4}|\d{3}[-\.\s]??\d{4}'
email_id = re.findall(email_regex,text)
phone_number = re.findall(phone_regx,text)
details = {
    'email': email_id[0],
    'phone_number': phone_number[0]
}
print(details)




